var global = tinymce.util.Tools.resolve('{$globalId}');

export default global;
export var {$globalName} = global;
